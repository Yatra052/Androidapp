package com.example.votenow.utils;

public class ApiConstants {
}
